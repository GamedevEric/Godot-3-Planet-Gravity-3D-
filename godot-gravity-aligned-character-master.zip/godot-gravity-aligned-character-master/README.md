### [Godot Gravity Aligned Character](https://git.leonardmeagher2.com/godot-gravity-aligned-character)

This demo is of a kinematic character that is aligned to gravity and can walk on a curved surface.  
This is based on a prototype I worked on.

Please create an issue for any suggestions, or even better fork this repo, make your changes and submit a pull request!

![](gravity-aligned-character.gif?raw=true)
